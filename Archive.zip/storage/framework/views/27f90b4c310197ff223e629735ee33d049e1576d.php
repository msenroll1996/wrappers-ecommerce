<!--

=========================================================
* Now UI Dashboard - v1.5.0
=========================================================

* Product Page: https://www.creative-tim.com/product/now-ui-dashboard
* Copyright 2019 Creative Tim (http://www.creative-tim.com)

* Designed by www.invisionapp.com Coded by www.creative-tim.com

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

-->

<?php $__env->startSection('title'); ?>
  View <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('search'); ?>
<!-- <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route("backend.product.index")); ?>">
                  List Product
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route("backend.product.add")); ?>">
                  Add Product
                </a>
              </li>
</ul> -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="row">
          <div class="col-md-6">
            <div class="card">
              <div class="card-header">
                <h5 class="title">Order Details</h5>
              </div>
              <hr>
              <div class="card-body">
                <p><b>Order No.:</b> <?php echo e($order->order_no); ?></p>
                <p><b>Customer Name:</b> <?php echo e($order->user->first_name.' '.$order->user->last_name); ?></p>
                <p><b>Customer Phone:</b> <?php echo e($order->user->phone); ?></p>
                <p><b>Total Ordered Quantity:</b> <?php echo e($order->total_quantity); ?></p>
                <p><b>Total Amount:</b> <?php echo e($order->total_price); ?></p>
                <p><b>Payment Method:</b> <?php echo e($order->payment_method); ?></p>
                <p><b>Paid Status:</b> <?php echo e($order->is_paid == true ? 'Paid' : 'Unpaid'); ?></p>
                <p><b>Ship To:</b> <?php echo e($order->shipping_first_name.' '.$order->shipping_last_name); ?></p>
                <p><b>Shipping Address: </b><?php echo e($order->shipping_address); ?></p>
                <p><b>Shipping Street: </b><?php echo e($order->shipping_street); ?></p>
                <p><b>Shipping Phone: </b><?php echo e($order->shipping_phone); ?></p>
              </div>
            </div>
                      <div class="row">
                        <?php if($order->status == 'pending'): ?>
                        <div class="col-md-4">
                          <button class="btn btn-secondary btn-block" onclick="window.location.href = '<?php echo e(route('backend.order.process',['id' => $order->id])); ?>'">Process this order</button>
                        </div>
                        <div class="col-md-4">
                          <button type = "button" class="btn btn-primary btn-block" onclick="javascript:confirmDelete(<?php echo e($order->id); ?>)" route = "<?php echo e(route('backend.order.decline',['id' => $order->id])); ?>" id = "decline<?php echo e($order->id); ?>">Decline this order</button>
                        </div>
                        <?php endif; ?>
                        <?php if($order->status == 'processing'): ?>
                        <div class="col-md-4">
                          <button class="btn btn-secondary btn-block" onclick="window.location.href = '<?php echo e(route('backend.order.complete',['id' => $order->id])); ?>'">Complete this order</button>
                        </div>
                        <?php endif; ?>

                      </div>
                    </div>
          
          
          <div class="col-md-6">
            <div class="card card-user">
              <div class="image">
              <h4 style = "text-align:center">Order Item Details</h4>
              </div>
              <div class="card-body">
                <div class="author">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
                      <th>
                        Product
                      </th>
                      <th>
                        Quantity
                      </th>
                      <th class="text-right">
                        Price
                      </th>
                     
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td>
                          <?php echo e($product->name); ?>

                        </td>
                        <td>
                        <?php echo e($product->pivot->quantity); ?>

                        </td>
                        
                        <td class="text-right">
                        <?php echo e($product->pivot->price); ?>

                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     
                    </tbody>
                  </table>
                </div>
                
              </div>
              <hr>
              <!-- <div class="button-container">
                <button href="#" class="btn btn-neutral btn-icon btn-round btn-lg">
                  <i class="fab fa-facebook-f"></i>
                </button>
                <button href="#" class="btn btn-neutral btn-icon btn-round btn-lg">
                  <i class="fab fa-twitter"></i>
                </button>
                <button href="#" class="btn btn-neutral btn-icon btn-round btn-lg">
                  <i class="fab fa-google-plus-g"></i>
                </button>
              </div> -->
            </div>
          </div>
          
        </div>
    </div>
    <?php $__env->startSection('script'); ?>

      <script src="<?php echo e(URL::asset('backend/assets/js/main.js')); ?>"></script>
      <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/wrappers-wrap/resources/views/backend/admin/orders/edit_form.blade.php ENDPATH**/ ?>