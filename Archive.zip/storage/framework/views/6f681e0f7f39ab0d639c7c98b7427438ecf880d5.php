<?php $__env->startSection('content'); ?>
<main class="site__main">
            <!-- Default page -->
            <section class="site__default site__add-to-cart uk-padding uk-padding-remove-horizontal ">
                <div class="uk-container-expand uk-padding uk-padding-remove-vertical">
                    <div class="site__add-to-cart__header">
                        <h1>Shipping</h1>
                    </div>
                    <div class="breadcrumb">
                        <ul class="breadcrumb-list">
                            <li><a href="<?php echo e(route('frontend.cart.index')); ?>">Cart</a></li>
                            <li><span>Shipping</span></li>
                            <!-- <li><span>Payment</span></li> -->
                        </ul>
                    </div>
                    <div class='uk-grid-large' uk-grid>
                        <div class="uk-width-1-1 uk-width-2-3@l">
                            <h2>Shipping Address</h2>
                            <hr class="uk-divider-icon">
                            <form action="<?php echo e(route('frontend.shipping.post_shipping')); ?>" method = "post" class="shipping-form">
                                <?php echo csrf_field(); ?>
                                <div class="uk-grid-small" uk-grid>
                                    <div class="uk-width-1-2@l">
                                        <div class="uk-margin">
                                            <label>First Name</label>
                                            <input type="text" name = "shipping_first_name" class="uk-input" value = "<?php echo e(auth()->user()->first_name); ?>" placeholder="First Name" required>
                                        </div>
                                    </div>
                                    <div class="uk-width-1-2@l">
                                        <div class="uk-margin">
                                        <label>Last Name</label>
                                            <input type="text" name = "shipping_last_name" class="uk-input" value = "<?php echo e(auth()->user()->last_name); ?>" placeholder="Last Name" required>
                                        </div>
                                    </div>
                                    <div class="uk-width-1-1">
                                        <div class="uk-margin">
                                        <label>Address</label>
                                            <input type="text" name = "shipping_address" class="uk-input" placeholder="Address" value = "<?php echo e(Session::get('shipping_info')['shipping_address']); ?>" required>
                                        </div>
                                    </div>
                                    <div class="uk-width-1-1">
                                        <div class="uk-margin">
                                        <label>Street</label>
                                            <input type="text" name = "shipping_street" value = "<?php echo e(Session::get('shipping_info')['shipping_street']); ?>" class="uk-input" placeholder="Appartment, suite, etc." required>
                                        </div>
                                    </div>
                                   
                                    <div class="uk-width-1-2@l">
                                        <div class="uk-margin">
                                        <label>Postal Code</label>
                                            <input type="text" name = "shipping_postal_code" value = "<?php echo e(Session::get('shipping_info')['shipping_postal_code']); ?>"  class="uk-input" placeholder="Postal Code" required>
                                        </div>
                                    </div>
                                    <div class="uk-width-1-1">
                                        <div class="uk-margin">
                                        <label>Phone</label>
                                            <input type="text" name = "shipping_phone" value = "<?php echo e(auth()->user()->phone); ?>" class="uk-input" placeholder="Phone Number" required>
                                        </div>
                                    </div>
                                    <div class="uk-width-1-1">
                                        <div class="uk-margin">
                                            <label><input class="uk-checkbox" type="checkbox" checked> Save this information for next time </label>
                                        </div>
                                    </div>
                                    <div class="uk-width-1-1">
                                        <div class="uk-margin">
                                            <button class="uk-button uk-button-large uk-button-primary">Continue to Shipping</button>
                                            <a href="<?php echo e(route('frontend.cart.index')); ?>" class="uk-button uk-button-default">Return to Cart </a>
                                        </div>
                                    </div>
                                </div>
                            </form>

                        </div>
                        
                        <div class="uk-width-1-1 uk-width-1-3@l">
                            <aside class="uk-width-2-3@l">
                            <?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="uk-flex uk-flex-middle uk-flex-between">
                                    <div class="uk-flex uk-flex-middle">
                                        <figure class="uk-position-relative" style="margin-bottom: 0;">
                                            <img src="<?php echo e(url( 'storage/'.$item['item']->image_first )); ?>" class="uk-border-rounded aside-produt-img" alt="">
                                            <span class="uk-badge uk-position-absolute uk-position-top-right"><?php echo e($item['qty']); ?></span>
                                        </figure>
                                        <div style="margin-left: 10px;"><?php echo e($item['item']->name); ?></div>
                                    </div>
                                    <div class="uk-text-secondary uk-text-bold">Rs. <?php echo e($item['price']); ?></div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                
                                <hr>
                                <form action="" class="uk-margin uk-grid-small uk-flex-stretch" uk-grid>
                                    <div class="uk-width-expand">
                                        <input type="text" placeholder="Gift card discount code" class="uk-input">
                                    </div>
                                    <div>
                                        <button class="uk-button uk-button-secondary uk-button-small">Apply</button>
                                    </div>
                                </form>
                                <hr>
                                <div class="uk-flex uk-flex-middle uk-flex-between">
                                    <div class="uk-text-secondary">Subtotal</div>
                                    <div class="uk-text-secondary uk-text-bold">Rs. <?php echo e($cart->totalPrice); ?></div>
                                </div>
                                <div class="uk-flex uk-flex-middle uk-flex-between">
                                    <div class="uk-text-secondary">Shipping</div>
                                    <div class="uk-text-secondary uk-text-bold">Calculated at next step</div>
                                </div>
                                <hr>
                                <div class="uk-flex uk-flex-middle uk-flex-between">
                                    <div class="uk-text-secondary">Total</div>
                                    <div class="uk-text-secondary uk-text-bold">Rs. <?php echo e($cart->totalPrice); ?></div>
                                </div>
                            </aside>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Default page end -->
        </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/wrappers-wrap/resources/views/frontend/checkout/shipping.blade.php ENDPATH**/ ?>