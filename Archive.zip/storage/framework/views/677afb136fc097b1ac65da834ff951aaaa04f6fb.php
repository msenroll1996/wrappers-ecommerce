<?php $__env->startSection('title'); ?>
  List <?php echo e($urlTitle); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('search'); ?>
<ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active" href="<?php echo e(route("backend.order.pending")); ?>">
                  Pending Orders
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route("backend.order.processing")); ?>">
                  Processing Orders
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route("backend.order.completed")); ?>">
                  Completed Orders
                </a>
              </li>
</ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<div class="content">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
            <div class="flash-message">
    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if(Session::has('alert-' . $msg)): ?>

      <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div> <!-- end .flash-message -->
              <div class="card-header">
                <h4 class="card-title"> <?php echo e($title); ?></h4>
                
         
  
             
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
                      <th>
                        Order No.
                      </th>
                      <th>
                        Customer
                      </th>
                      <th>
                        Total Items
                      </th>
                      <th>
                        Total Price
                      </th>
                      <th>
                        Payment Method
                      </th>
                      <th>
                        Paid
                      </th>
                      <th>
                        Status
                      </th>
                      <th class="text-right">
                        Action
                      </th>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                          <td>
                            <?php echo e($order->order_no); ?>

                          </td>
                          <td>
                          <?php echo e($order->user->first_name.' '.$order->user->last_name); ?>

                          </td>
                          <td>
                          <?php echo e($order->total_quantity); ?>

                          </td>
                          <td>
                          <?php echo e($order->total_price); ?>

                          </td>
                          <td>
                          <?php echo e($order->payment_method); ?>

                          </td>
                          <td>
                          <?php echo e($order->is_paid ? 'Paid' : 'Not Paid'); ?>

                          </td>
                          <td>
                          <?php echo e($order->status); ?>

                          </td>
                          <!-- <td>
                          <?php if($order->status == 1): ?><?php echo e('Active'); ?><?php else: ?><?php echo e('In-active'); ?><?php endif; ?>
                          </td> -->
                           <td class="text-right">
                            <a  href="<?php echo e(route('backend.order.edit',['id' => $order->id])); ?>"><i data-toggle="tooltip" data-placement="top" title="Edit" class="far fa-edit"></i></a>&nbsp;&nbsp;
                            <?php if($order->status == 'pending'): ?>
                            <a onclick="return confirm('Are you sure to decline this order?')" href = "<?php echo e(route('backend.order.decline',['id' => $order->id])); ?>"><i data-toggle="tooltip" data-placement="top" title="Delete" class="far fa-trash-alt"></i></a>
                            <?php endif; ?>
                          </td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
          
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/wrappers-wrap/resources/views/backend/admin/orders/index.blade.php ENDPATH**/ ?>