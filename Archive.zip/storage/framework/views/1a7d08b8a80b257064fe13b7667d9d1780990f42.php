<?php $__env->startSection('content'); ?>
<!-- Main -->
<main class="site__main">
            <!-- Default page -->
            <section class="site__default uk-padding uk-padding-remove-horizontal ">
                <div class="uk-container-expand uk-padding uk-padding-remove-vertical">
                    <div class="site__default__content">
                        <h1>Lorem ipsum dolor sit amet.</h1>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorum illum est, rem doloremque unde fugit culpa, in et eum ratione sed necessitatibus hic cum dolores voluptates alias amet soluta. Numquam.</p>
                        <p><span>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Molestias facilis dignissimos neque beatae quo inventore reiciendis culpa perferendis ipsa dolore, molestiae unde nam porro, tempore maxime omnis doloremque maiores ea!</span><span>Mollitia aut facilis praesentium ex iste, repudiandae architecto sunt distinctio tempore beatae nulla veritatis culpa ad voluptatem porro eveniet minus accusamus, quasi explicabo est ea? Voluptas, velit iste. Corrupti, voluptatum.</span></p>
                        <ul>
                            <li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos, sit!</li>
                            <li>Qui, quas deserunt natus sapiente obcaecati cupiditate voluptatibus velit voluptatum.</li>
                            <li>Dolorum atque tenetur blanditiis sed dolor officia aspernatur reprehenderit necessitatibus.</li>
                            <li>Obcaecati fugiat ipsa officiis necessitatibus et, ducimus deleniti quaerat vel?</li>
                            <li>Aliquam vero saepe incidunt eligendi cum sapiente vel aut earum.</li>
                        </ul>
                        <ol>
                            <li>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Itaque, voluptates!</li>
                            <li>Consequuntur tempore odit laboriosam eveniet quos recusandae hic. Quas, dicta?</li>
                            <li>Dolorem debitis, obcaecati nesciunt ad corporis eaque consectetur eum ipsum!</li>
                            <li>Eos dolorem distinctio enim molestiae similique sapiente placeat necessitatibus ut.</li>
                            <li>Nostrum labore ratione reiciendis expedita consectetur fugiat earum, sint eum.</li>
                        </ol>
                        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nihil nam, libero impedit vel facilis ratione odit sapiente blanditiis doloremque numquam, a iure eveniet voluptatem perferendis possimus? Facilis alias nesciunt ex?</p>
                        <p>Quam nemo alias id repellendus incidunt quas natus nulla non culpa eveniet exercitationem quae quibusdam cupiditate, assumenda esse cum similique, obcaecati dignissimos illum illo eius consectetur. Dignissimos maxime similique voluptates?</p>
                        <p>Nihil eos omnis provident dolores ipsa, reprehenderit molestiae incidunt facilis ex accusamus sequi cupiditate eveniet distinctio deleniti voluptatem magnam suscipit! Consequatur cum consequuntur cupiditate amet aliquid tenetur provident quasi quam.</p>
                        <p>Ab enim temporibus aperiam quam voluptatibus! Omnis cumque nesciunt natus beatae tempora minima odit vitae impedit quas, odio distinctio dignissimos porro nostrum ea. Enim itaque labore tempora officia quia repellat!</p>
                    </div>
                </div>
            </section>
            <!-- Default page end -->
        </main>
        <!-- Main end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/wrappers-wrap/resources/views/frontend/default_page.blade.php ENDPATH**/ ?>