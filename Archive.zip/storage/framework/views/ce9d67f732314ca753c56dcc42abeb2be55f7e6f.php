<!--

=========================================================
* Now UI Dashboard - v1.5.0
=========================================================

* Product Page: https://www.creative-tim.com/product/now-ui-dashboard
* Copyright 2019 Creative Tim (http://www.creative-tim.com)

* Designed by www.invisionapp.com Coded by www.creative-tim.com

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

-->

<?php $__env->startSection('title'); ?>
  Edit <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('search'); ?>
<ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route("backend.category.index")); ?>">
                  List categories
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route("backend.category.add")); ?>">
                  Add category
                </a>
              </li>
</ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="row">
          <div class="col-md-8">
            <div class="card">
              <div class="card-header">
                <h5 class="title"> Edit <?php echo e($title); ?></h5>
              </div>
              <div class="card-body">
                <form method = "POST" action = "<?php echo e(route('backend.category.update',['id' => $old_category->id])); ?>" enctype="multipart/form-data">
                  <?php echo e(csrf_field()); ?>

                  <div class="row">
                    <div class="col-md-6 pr-1">
                      <div class="form-group">
                      <label>Parent</label>
                      <select name="parent_id" class="form-control">
                      <option value = "" <?php echo e($old_category->parent_id == null ? 'selected' : ''); ?>>None</option>
                      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value = "<?php echo e($category->id); ?>" <?php echo e($category->id == $old_category->parent_id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                          <?php $__currentLoopData = App\Models\Category::where('parent_id',$category->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($child_category->id); ?>" <?php echo e($child_category->id == $old_category->parent_id ? 'selected' : ''); ?> ><?php echo e($category->name.' > '.$child_category->name); ?></option>
                          <!-- <?php $__currentLoopData = App\Models\Category::where('parent_id',$child_category->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($child->id); ?>"><?php echo e($category->name.' > '.$child_category->name.' > '.$child->name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($c->id); ?>" <?php echo e($c->id == $category->parent_id ? 'selected' : ''); ?>><?php echo e($c->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                      </select> 
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6 pr-1">
                      <div class="form-group">
                        <label for = "name">Name</label>
                        <input type="text" id = "name" name = "name" value = "<?php echo e($old_category->name); ?>" class="form-control" placeholder="Enter category name" required/>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6 pr-1">
                      <div class="form-group">
                        <label for = "slug">Slug</label>
                        <input type = "text" value = "<?php echo e($old_category->slug); ?>" class="form-control" id = "slug" name = "slug" placeholder="" required/>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-4 pr-1">
                      <div>
                        <label for = "cover_image">Cover Image</label>
                        <input type="file" name = "cover_image" class="form-control">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12 pr-1">
                      <div>
                        <label for = "description">Desription</label>
                        <textarea  class="form-control" id = "description" name = "description" placeholder=""><?php echo e($old_category->description); ?></textarea>
                      </div>
                    </div>
                </div>
                  <div class="row">
                    <div class="col-md-6 pr-1">
                  <label>Status</label>
                      <div class="form-group">
                        <input type="radio" name = "status"  value = "1" id = "active" <?php echo e($old_category->status == true ? 'checked' : ''); ?> required/>

                        <label for = "active" >Active</label>

                        <input type="radio" name = "status"  value = "0" id = "in-active" <?php echo e($old_category->status == false ? 'checked' : ''); ?>  required/>

                        <label for = "in-active" >In-active</label>

                        
                      </div>
                    </div>
                  </div>
                  
                  <!-- <div class="row">
                    <div class="col-md-4 pr-1">
                      <div>
                        <label for = "image">Image</label>
                        <input type="file" name = "image" class="form-control">
                      </div>
                    </div>
                  </div> -->
                  <div class="row">
                  <div class="col-md-4">
                      <button type = "submit" class="btn btn-primary btn-block">Edit</button>
                  </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
          
          <?php if($old_category->cover_image != null): ?>
          <div class="col-md-4">
            <div class="card card-user">
              <div class="image">
              </div>
              <div class="card-body">
                <div class="author">
                  <a>
                    <img class="avatar border-gray" src="<?php echo e(url( 'storage/'.$old_category->cover_image )); ?>" alt="No image">
                    <h5 class="title"><?php echo e($old_category->name); ?></h5>
                  </a>
                  
                  
                </div>
                
              </div>
              <!-- <div class="button-container">
                <button href="#" class="btn btn-neutral btn-icon btn-round btn-lg">
                  <i class="fab fa-facebook-f"></i>
                </button>
                <button href="#" class="btn btn-neutral btn-icon btn-round btn-lg">
                  <i class="fab fa-twitter"></i>
                </button>
                <button href="#" class="btn btn-neutral btn-icon btn-round btn-lg">
                  <i class="fab fa-google-plus-g"></i>
                </button>
              </div> -->
            </div>
          </div>
          <?php endif; ?>
        </div>
    </div>
    <?php $__env->startSection('script'); ?>
      <script>
            $('#name').change(function (e) {
              $.get("<?php echo e(route('backend.category.check_slug')); ?>",
                  { 'name': $(this).val() },
                  function (data) {
                      $('#slug').val(data.slug);
                  }
              );
              
            });
          </script>
        <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/wrappers-wrap/resources/views/backend/admin/categories/edit_form.blade.php ENDPATH**/ ?>