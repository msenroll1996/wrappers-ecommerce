<?php $__env->startSection('title'); ?>
  Add <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('search'); ?>
<ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route("backend.sub_category.index")); ?>">
                  List Sub Category
                </a>
              </li>
</ul>
<?php $__env->stopSection(); ?>
<div class="content">
        <div class="row">
          <div class="col-md-10">
            <div class="card">
              <div class="card-header">
                <h5 class="title"> Add <?php echo e($title); ?></h5>
                
              </div>
              <div class="card-body">
                <form method = "POST" action = "<?php echo e(route('backend.sub_category.store')); ?>">
                  <?php echo e(csrf_field()); ?>

                  <div class="row">
                    <div class="col-md-6 pr-1">
                      <div class="form-group">
                      <label>Select Category</label>
                      <select name="category_id" id="gender" class="form-control" required>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select> 
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-6 pr-1">
                      <div class="form-group">
                      <label>Name</label>
                        <input type="text" name = "name" class="form-control" placeholder="Enter Sub Category Name" required>
                      </div>
                    </div>
                  </div>
                  
                  <div class="row">
                    <div class="col-md-6 pr-1">
                  <label>Status</label>
                      <div class="form-group">
                        <input type="radio" name = "status"  value = "1" id = "active" checked  required>

                        <label for = "active" >Active</label>

                        <input type="radio" name = "status"  value = "0" id = "in-active"  required>

                        <label for = "in-active" >In-active</label>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                  <div class="col-md-6">
                        <button type = "submit" class="btn btn-primary btn-block">Submit</button>
                  </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
          
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/wrappers-wrap/resources/views/backend/admin/sub_categories/add_form.blade.php ENDPATH**/ ?>